module.exports = {
  reactStrictMode: true,
  images: {
    loader: "akamai",
    path: ""
  },
  basePath: "/skd",
  assetPrefix: "/skd"
}
